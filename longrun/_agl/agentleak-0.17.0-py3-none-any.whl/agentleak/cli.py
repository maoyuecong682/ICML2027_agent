# SPDX-FileCopyrightText: 2026 AgentLeak contributors
# SPDX-License-Identifier: MIT
"""``agentleak`` command-line interface.

Commands: init, run, report, validate, scenarios, version.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

import typer

from . import __version__
from .core.canary import CanarySet
from .core.config import DEFAULT_CONFIG_YAML, Config
from .core.report import AnalysisResult
from .core.runner import AgentLeakRunner
from .core.trace import Trace
from .reporters import normalize_formats, render, write_reports
from .scenarios import list_scenarios, load_example_trace

app = typer.Typer(
    add_completion=False,
    help="AgentLeak OSS — local privacy-leakage testing for AI agents.",
    no_args_is_help=True,
)

_VERDICT_COLORS = {
    "Pass": typer.colors.GREEN,
    "Conditional pass": typer.colors.YELLOW,
    "High risk": typer.colors.BRIGHT_YELLOW,
    "Fail": typer.colors.RED,
}
_LEVEL_COLORS = {
    "critical": typer.colors.RED,
    "high": typer.colors.BRIGHT_YELLOW,
    "medium": typer.colors.YELLOW,
    "low": typer.colors.GREEN,
    "none": typer.colors.WHITE,
}
_INTERNAL_CHANNELS = {
    "tool_call", "shared_memory", "log", "inter_agent_message", "generated_file",
}


# ----------------------------------------------------------------------
# version
# ----------------------------------------------------------------------
@app.command()
def version() -> None:
    """Print the AgentLeak version."""
    typer.echo(f"agentleak {__version__}")


# ----------------------------------------------------------------------
# init
# ----------------------------------------------------------------------
@app.command()
def init(
    path: str = typer.Argument(".", help="Directory to initialize."),
    force: bool = typer.Option(False, "--force", help="Overwrite an existing config."),
) -> None:
    """Scaffold an AgentLeak project (config + folders + a sample trace)."""
    root = os.path.abspath(path)
    os.makedirs(root, exist_ok=True)
    for sub in ("scenarios", "reports", "traces"):
        os.makedirs(os.path.join(root, sub), exist_ok=True)

    config_path = os.path.join(root, "agentleak.yaml")
    if os.path.exists(config_path) and not force:
        typer.secho(f"! {config_path} already exists (use --force to overwrite).", fg=typer.colors.YELLOW)
    else:
        with open(config_path, "w", encoding="utf-8") as fh:
            fh.write(DEFAULT_CONFIG_YAML)
        typer.secho(f"✓ wrote {config_path}", fg=typer.colors.GREEN)

    # Drop a runnable sample trace so `agentleak run` works immediately.
    sample = load_example_trace("healthcare_patient_summary")
    sample_path = os.path.join(root, "traces", "example_trace.json")
    with open(sample_path, "w", encoding="utf-8") as fh:
        json.dump(sample.to_dict(), fh, indent=2)
    typer.secho(f"✓ wrote {sample_path}", fg=typer.colors.GREEN)

    typer.echo("")
    typer.echo("Next steps:")
    typer.echo("  agentleak run --trace traces/example_trace.json")
    typer.echo("  agentleak run --scenario healthcare_patient_summary")


# ----------------------------------------------------------------------
# validate
# ----------------------------------------------------------------------
@app.command()
def validate(
    config: str = typer.Argument("agentleak.yaml", help="Path to the config file."),
    trace: str | None = typer.Option(None, "--trace", "-t", help="Also validate a trace file."),
) -> None:
    """Validate a configuration (and optionally a trace) file."""
    ok = True
    try:
        cfg = Config.load(config)
        typer.secho(f"✓ config valid: {config}", fg=typer.colors.GREEN)
        typer.echo(f"  detectors: {', '.join(k for k, v in cfg.detectors.as_dict().items() if v) or 'none'}")
        typer.echo(f"  channels:  {len(cfg.channels)} · scenarios: {len(cfg.scenarios)}")
        normalize_formats(cfg.reports.formats)
    except FileNotFoundError:
        typer.secho(f"✗ config not found: {config}", fg=typer.colors.RED)
        ok = False
    except Exception as exc:  # noqa: BLE001 - surface any validation error
        typer.secho(f"✗ invalid config: {exc}", fg=typer.colors.RED)
        ok = False

    if trace:
        try:
            t = Trace.from_json_file(trace)
            typer.secho(f"✓ trace valid: {trace} ({len(t.events)} events)", fg=typer.colors.GREEN)
        except Exception as exc:  # noqa: BLE001
            typer.secho(f"✗ invalid trace: {exc}", fg=typer.colors.RED)
            ok = False

    raise typer.Exit(code=0 if ok else 1)


# ----------------------------------------------------------------------
# scenarios
# ----------------------------------------------------------------------
@app.command()
def scenarios(
    packs: bool = typer.Option(False, "--packs", help="List bundled scenario packs (research benchmarks) instead."),
    pack: str | None = typer.Option(None, "--pack", help="List the scenarios inside one pack, e.g. agentleak_bench."),
) -> None:
    """List the scenarios you can run: built-ins, or a bundled research pack.

    Built-ins are the quick leak/clean pairs per domain. The packs ship the
    published benchmark suites; run any of their scenarios directly with
    ``agentleak run --pack <pack_id> --scenario <id>``.
    """
    from .scenarios.packs import expand_pack, list_packs

    if packs:
        for entry in list_packs():
            typer.secho(entry["id"], fg=typer.colors.CYAN, bold=True)
            typer.echo(f"  {entry['description'] or entry['name']}")
            typer.echo(f"  {entry['count']} scenario(s) · source: {entry['source'] or 'bundled'}")
            if entry.get("license"):
                typer.echo(f"  licence: {entry['license']}")
            typer.echo(f"  run one: agentleak run --pack {entry['id']} --scenario <id>")
        return

    if pack:
        try:
            entries = expand_pack(pack)
        except (KeyError, FileNotFoundError, ValueError) as exc:
            typer.secho(f"✗ unknown pack: {pack}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
        for meta, _trace in entries:
            typer.secho(meta.get("origin_id") or meta.get("name", "?"), fg=typer.colors.CYAN, bold=True)
            if meta.get("description"):
                typer.echo(f"  {meta['description']}")
        typer.echo(f"\n{len(entries)} scenario(s) in {pack}.")
        return

    for s in list_scenarios():
        typer.secho(s.id, fg=typer.colors.CYAN, bold=True)
        typer.echo(f"  {s.description}")
        typer.echo(f"  domain: {s.domain} · sensitive: {', '.join(s.sensitive_data)}")
    typer.echo("\nAlso available: agentleak scenarios --packs  (research benchmark suites)")


# ----------------------------------------------------------------------
# agent-card (offline A2A discovery card for THIS AgentLeak instance)
# ----------------------------------------------------------------------
@app.command(name="agent-card")
def agent_card_cmd() -> None:
    """Print AgentLeak's own A2A/Nasiko agent card (no server needed).

    The same document is served unauthenticated at
    ``/.well-known/agent-card.json`` by ``agentleak serve`` — this command
    lets an agent (or a human) discover AgentLeak's capabilities offline.
    """
    from .core.agentcard import platform_card

    typer.echo(json.dumps(platform_card(__version__).to_dict(), indent=2))


@app.command()
def schema(
    name: str = typer.Argument("catalog", help="Schema name, or 'catalog'."),
) -> None:
    """Print a public AgentLeak JSON Schema for IDEs, CI, or agents."""
    from .core.schemas import get_schema, schema_catalog

    try:
        payload = schema_catalog() if name == "catalog" else get_schema(name)
    except KeyError as exc:
        typer.secho(f"✗ {exc.args[0]}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    typer.echo(json.dumps(payload, indent=2))


# ----------------------------------------------------------------------
# skill (register AgentLeak with coding agents)
# ----------------------------------------------------------------------
_SKILL_STATUS_COLORS = {
    "current": typer.colors.GREEN,
    "installed": typer.colors.GREEN,
    "updated": typer.colors.GREEN,
    "unchanged": typer.colors.BRIGHT_BLACK,
    "stale": typer.colors.YELLOW,
    "conflict": typer.colors.RED,
    "missing": typer.colors.YELLOW,
    "removed": typer.colors.GREEN,
    "absent": typer.colors.BRIGHT_BLACK,
}
_SKILL_STATUS_LABELS = {
    "current": "up to date",
    "installed": "installed",
    "updated": "updated",
    "unchanged": "already up to date",
    "stale": "outdated — rerun with --install --force",
    "conflict": "differs from ours — use --force to overwrite",
    "missing": "not installed",
    "removed": "removed",
    "absent": "agent not detected",
}


@app.command()
def skill(
    install: bool = typer.Option(False, "--install", help="Write SKILL.md into agent skills directories."),
    uninstall: bool = typer.Option(False, "--uninstall", help="Remove a previously installed skill."),
    show: bool = typer.Option(False, "--print", help="Print the SKILL.md text to stdout."),
    target: list[str] = typer.Option(
        None, "--target", "-t", help="Limit to specific agents (repeatable). Default: all detected."
    ),
    path: str | None = typer.Option(
        None, "--path", help="Install into an explicit skills directory instead of auto-detecting."
    ),
    force: bool = typer.Option(False, "--force", help="Overwrite a skill file that differs from ours."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would happen, write nothing."),
) -> None:
    """Register AgentLeak as a skill so coding agents discover it on their own.

    With no flags, reports where the skill is installed.
    """
    from . import skill as skill_mod

    if show:
        typer.echo(skill_mod.skill_text())
        return

    if install and uninstall:
        typer.secho("✗ --install and --uninstall are mutually exclusive.", fg=typer.colors.RED)
        raise typer.Exit(code=2)

    # --- resolve which locations we operate on --------------------------------
    if path is not None:
        locations = [(Path(path).expanduser(), path)]
    else:
        if target:
            try:
                targets = [skill_mod.target_by_id(t) for t in target]
            except KeyError as exc:
                typer.secho(f"✗ {exc.args[0]}", fg=typer.colors.RED)
                raise typer.Exit(code=2) from exc
        else:
            targets = skill_mod.detect_targets()
        locations = [(t.skills_path(), t.label) for t in targets]

    # --- status (no flags) ----------------------------------------------------
    if not install and not uninstall:
        rows = skill_mod.status()
        typer.echo("")
        typer.secho("👁️  AgentLeak skill", bold=True)
        typer.echo("")
        for tgt, state in rows:
            typer.secho(
                f"  {tgt.label:<14} {_SKILL_STATUS_LABELS[state]}",
                fg=_SKILL_STATUS_COLORS[state],
            )
        typer.echo("")
        if any(state in {"missing", "stale"} for _, state in rows):
            typer.echo("  Install with:  agentleak skill --install")
        elif not any(state != "absent" for _, state in rows):
            typer.echo("  No supported agent detected. Use --path <skills-dir> to install anyway.")
        return

    if not locations:
        typer.secho(
            "✗ No supported agent detected (Claude Code, OpenClaw, Cursor, Windsurf, Codex CLI).",
            fg=typer.colors.RED,
        )
        typer.echo("  Install into an explicit directory with:  agentleak skill --install --path <dir>")
        raise typer.Exit(code=1)

    # --- act ------------------------------------------------------------------
    outcomes = []
    for destination, label in locations:
        if uninstall:
            outcomes.append(skill_mod.uninstall(destination, label=label, dry_run=dry_run))
        else:
            outcomes.append(
                skill_mod.install(destination, force=force, label=label, dry_run=dry_run)
            )

    prefix = "[dry-run] " if dry_run else ""
    typer.echo("")
    for outcome in outcomes:
        mark = "✓" if outcome.ok else "✗"
        typer.secho(
            f"  {mark} {outcome.label or outcome.path.parent.name}: "
            f"{prefix}{_SKILL_STATUS_LABELS[outcome.status]}",
            fg=_SKILL_STATUS_COLORS[outcome.status],
        )
        if outcome.changed or outcome.status == "unchanged":
            typer.secho(f"      {outcome.path}", fg=typer.colors.BRIGHT_BLACK)
    typer.echo("")

    if any(not o.ok for o in outcomes):
        raise typer.Exit(code=1)
    if install and not dry_run:
        typer.echo("  Start a new agent session for the skill to be picked up.")


# ----------------------------------------------------------------------
# scan (static code privacy scan)
# ----------------------------------------------------------------------
@app.command()
def scan(
    path: str = typer.Argument(".", help="File, directory or zip archive to scan."),
    repo: str | None = typer.Option(None, "--repo", "-r", help="Scan a GitHub repo (owner/name) instead of a path."),
    branch: str = typer.Option("main", "--branch", help="Branch to scan with --repo."),
    config: str | None = typer.Option(None, "--config", "-c", help="agentleak.yaml (detector toggles, custom rules, detection mode)."),
    mode: str | None = typer.Option(None, "--mode", "-m", help="Detection mode: fast | standard (Presidio) | hybrid (Presidio + LLM-judge)."),
    output: str | None = typer.Option(None, "--output", "-o", help="Write the full result to a file."),
    fmt: str = typer.Option("json", "--format", "-f", help="Output format: json | sarif."),
    fail_under: int | None = typer.Option(None, "--fail-under", help="Exit non-zero when the code score is below this value."),
) -> None:
    """Static privacy scan of agent source code (file, dir, zip, or GitHub repo).

    Runs the same 3-tier hybrid pipeline as trace analysis (regex detectors,
    Presidio, LLM-judge) plus code-specific layers: entropy analysis,
    de-obfuscation of decomposed PII, and quasi-identifier correlation.
    """
    from .core.codescan import scan_github_repo, scan_path

    fmt = fmt.lower().strip()
    if fmt not in {"json", "sarif"}:
        typer.secho("✗ format must be 'json' or 'sarif'", fg=typer.colors.RED)
        raise typer.Exit(code=2)

    cfg: Config | None = None
    if config:
        try:
            cfg = Config.load(config)
        except (OSError, ValueError) as exc:
            typer.secho(f"✗ could not load config: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc
    if mode:
        # Mode override: standard enables Presidio, hybrid also enables the
        # LLM-judge (endpoint from AGENTLEAK_LLM_BASE_URL / _MODEL env vars).
        det: dict[str, object] = {
            "mode": mode,
            "presidio": {"enabled": mode in ("standard", "hybrid")},
            "llm_judge": {
                "enabled": mode in ("hybrid", "llm_only"),
                "base_url": os.environ.get("AGENTLEAK_LLM_BASE_URL", ""),
                "model": os.environ.get("AGENTLEAK_LLM_MODEL", ""),
            },
        }
        base = cfg.model_dump() if cfg else {}
        base["detection"] = {**base.get("detection", {}), **det}
        cfg = Config.from_dict(base)

    try:
        if repo:
            typer.echo(f"Fetching {repo}@{branch} …")
            result = scan_github_repo(repo, branch=branch, config=cfg)
        else:
            # scan_path dispatches on what the argument actually is: a single
            # file, a directory tree or a zip archive.
            result = scan_path(path, config=cfg)
    except (ValueError, OSError) as exc:
        typer.secho(f"✗ {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    summary = result.summary()
    color = typer.colors.GREEN if result.score >= 90 else (
        typer.colors.YELLOW if result.score >= 70 else typer.colors.RED
    )
    typer.secho(f"Code privacy score: {result.score}/100 — {result.verdict}", fg=color, bold=True)
    typer.echo(
        f"  mode: {result.detection_mode} · tiers: {', '.join(result.tiers)}\n"
        f"  files scanned: {summary['files_scanned']} · findings: {summary['total_findings']}"
        f" · levels: {summary['level_profile']}"
    )
    for f in result.findings[:25]:
        typer.echo(f"  [L{f.level}] {f.file}:{f.line} {f.rule} ({f.data_type}, {f.tier})")
        typer.echo(f"        {f.snippet}")
    if len(result.findings) > 25:
        typer.echo(f"  … and {len(result.findings) - 25} more (use --output for the full list)")

    if output:
        payload = result.to_sarif() if fmt == "sarif" else result.to_dict()
        Path(output).write_text(json.dumps(payload, indent=2), encoding="utf-8")
        typer.secho(f"✓ wrote {output}", fg=typer.colors.GREEN)

    if fail_under is not None and result.score < fail_under:
        typer.secho(f"✗ score {result.score} < fail-under {fail_under}", fg=typer.colors.RED)
        raise typer.Exit(code=1)


# ----------------------------------------------------------------------
# redact (runtime defense: sanitize before the data ever moves)
# ----------------------------------------------------------------------
@app.command()
def redact(
    path: str | None = typer.Argument(None, help="File to sanitize. Omit to read stdin."),
    style: str = typer.Option(
        "placeholder", "--style",
        help="placeholder | asterisk | masked | hash | category | remove.",
    ),
    output: str | None = typer.Option(None, "--output", "-o", help="Write to a file instead of stdout."),
) -> None:
    """Redact sensitive values from text, so a leak never happens in the first place.

    Detection tells you what leaked; this is the other half: the same rules
    applied as a defense. Pipe logs, prompts or tool payloads through it, or
    use ``agentleak.defenses.Sanitizer`` in-process for the same result.
    """
    from .defenses import RedactionStyle, sanitize_text

    valid = {s.value for s in RedactionStyle}
    # ``mask`` is what people type, and what this command's own help and docs
    # said for several releases while rejecting it.
    style = {"mask": "masked"}.get(style, style)
    if style not in valid:
        typer.secho(f"✗ style must be one of: {', '.join(sorted(valid))}", fg=typer.colors.RED)
        raise typer.Exit(code=2)

    try:
        text = Path(path).read_text(encoding="utf-8") if path else sys.stdin.read()
    except OSError as exc:
        typer.secho(f"✗ {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    cleaned = sanitize_text(text, style=style)
    if output:
        Path(output).write_text(cleaned, encoding="utf-8")
        typer.secho(f"✓ redacted → {output}", fg=typer.colors.GREEN)
    else:
        typer.echo(cleaned)


# ----------------------------------------------------------------------
# admin (operator-side account recovery for a self-hosted platform)
# ----------------------------------------------------------------------
admin_app = typer.Typer(help="Operator commands for a self-hosted platform.", no_args_is_help=True)
app.add_typer(admin_app, name="admin")


@admin_app.command("reset-password")
def admin_reset_password(
    email: str = typer.Argument(..., help="Email of the account to reset."),
    password: str | None = typer.Option(
        None, "--password", help="New password. Omit to be prompted (not echoed)."
    ),
) -> None:
    """Reset a platform account's password from the machine that owns the data.

    There is no emailed reset link: AgentLeak ships no mail infrastructure and
    keeps everything local. Recovery belongs to whoever holds the database, so
    run this on the host (or over SSH for a hosted instance). Every session for
    the account is revoked.
    """
    from .core.store import Store

    if not password:
        password = typer.prompt("New password", hide_input=True, confirmation_prompt=True)
    if len(password) < 8:
        typer.secho("✗ password must be at least 8 characters", fg=typer.colors.RED)
        raise typer.Exit(code=2)

    if Store().reset_password(email, password):
        typer.secho(f"✓ password reset for {email} (all sessions revoked)", fg=typer.colors.GREEN)
    else:
        typer.secho(f"✗ no account with email: {email}", fg=typer.colors.RED)
        raise typer.Exit(code=1)


@admin_app.command("list-users")
def admin_list_users() -> None:
    """List platform accounts (email, role, creation date)."""
    from .core.store import Store

    users = Store().list_users()
    if not users:
        typer.echo("No accounts yet.")
        return
    for user in users:
        role = "admin" if user.get("is_admin") else "user"
        state = " · disabled" if user.get("disabled") else ""
        typer.echo(f"{user['email']:<40} {role}{state}")
    typer.echo(f"\n{len(users)} account(s).")


# ----------------------------------------------------------------------
# serve (web GUI)
# ----------------------------------------------------------------------
@app.command()
def mcp() -> None:
    """Serve AgentLeak to coding agents over MCP (pip install 'agentleak\\[mcp]').

    Point an MCP-capable agent at this and it gets `privacy_preflight` and the
    scan/trace/redact primitives as native tools. Everything runs locally.
    """
    from .mcp_server import MCP_MISSING, run_stdio

    try:
        run_stdio()
    except RuntimeError as exc:
        typer.secho(str(exc), fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except ImportError as exc:  # the SDK import lives inside run_stdio
        typer.secho(MCP_MISSING, fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except KeyboardInterrupt:  # pragma: no cover - normal way to stop a server
        pass


@app.command(context_settings={"allow_extra_args": True, "ignore_unknown_options": True})
def proxy(
    ctx: typer.Context,
    config: str | None = typer.Option(None, "--config", "-c", help="agentleak.yaml holding the flow rules."),
    evidence: str = typer.Option("agentleak-evidence.jsonl", "--evidence", help="Hash-chained decision log."),
    recipient: str | None = typer.Option(None, "--recipient", help="Name this server goes by in flow rules."),
    block: bool = typer.Option(False, "--block", help="Block every refused flow instead of redacting it."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Don't narrate decisions on stderr."),
    inspect_responses: bool = typer.Option(
        False, "--inspect-responses",
        help="Also judge each tool result on its way back to the agent (server -> agent flows).",
    ),
    style: str = typer.Option(
        "placeholder", "--style",
        help="How removed values are rendered: placeholder | token (stable pseudonym, restored in responses) | masked | hash.",
    ),
    agent: str = typer.Option("mcp-client", "--agent", help="Name the agent goes by in flow rules."),
    pins: str = typer.Option(
        ".agentleak/mcp-pins.json", "--pins",
        help="Tool fingerprints, pinned on first use; a changed tool is reported. '' disables.",
    ),
    block_changed_tools: bool = typer.Option(
        False, "--block-changed-tools", help="Hide and refuse a tool whose definition changed since it was pinned.",
    ),
    repin: bool = typer.Option(False, "--repin", help="Accept every tool's current definition as the new pin."),
    sign_key: str | None = typer.Option(
        None, "--sign-key", envvar="AGENTLEAK_EVIDENCE_KEY",
        help="Ed25519 private key; signs every evidence entry (pip install 'agentleak\\[sign]').",
    ),
) -> None:
    """Guard an MCP server: judge every tool call before it is sent.

    Put this between your agent and the server it calls. Arguments after `--`
    are the server command:

      agentleak proxy --config agentleak.yaml -- npx -y @modelcontextprotocol/server-github

    Each `tools/call` is checked against the contextual-integrity rules in your
    config: permitted flows pass, refused ones have the offending values removed,
    and flows a `deny` rule names are refused outright with a reason the agent
    can read. Every decision is appended to a hash-chained evidence log that
    `agentleak evidence` can verify.
    """
    from .defenses import RedactionStyle

    if {"mask": "masked"}.get(style, style) not in {x.value for x in RedactionStyle}:
        typer.secho(f"✗ unknown --style {style!r}", fg=typer.colors.RED)
        raise typer.Exit(code=2)
    command = list(ctx.args)
    if not command:
        typer.secho(
            "No server command. Put it after `--`, e.g.\n"
            "  agentleak proxy -- npx -y @modelcontextprotocol/server-github",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=2)

    flows: Any = None
    groups: dict[str, Any] = {}
    if config:
        try:
            cfg = Config.load(config)
            flows = list(cfg.privacy_policy.flows)
            groups = dict(cfg.privacy_policy.groups)
        except Exception as exc:  # noqa: BLE001
            typer.secho(f"✗ could not load config: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=2) from exc
        if not flows:
            typer.secho(
                "Note: the config declares no privacy_policy.flows, so nothing is "
                "refused. Every call is still recorded.",
                fg=typer.colors.YELLOW, err=True,
            )

    from .mcp_proxy import run_proxy

    try:
        code = run_proxy(
            command,
            flows=flows,
            evidence=evidence,
            recipient=recipient or "",
            block_on_violation=block,
            verbose=not quiet,
            inspect_responses=inspect_responses,
            style={"mask": "masked"}.get(style, style),
            agent=agent,
            groups=groups,
            sign_key=sign_key,
            pins_path=pins or None,
            block_changed_tools=block_changed_tools,
            repin=repin,
        )
    except FileNotFoundError as exc:
        typer.secho(f"✗ could not start the server: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    except KeyboardInterrupt:  # pragma: no cover
        code = 0
    raise typer.Exit(code=code)


@app.command("llm-proxy")
def llm_proxy(
    upstream: str = typer.Option(..., "--upstream", help="Model API to forward to, e.g. https://api.openai.com"),
    config: str | None = typer.Option(None, "--config", "-c", help="agentleak.yaml holding the flow rules."),
    evidence: str = typer.Option("agentleak-evidence.jsonl", "--evidence", help="Hash-chained decision log."),
    host: str = typer.Option("127.0.0.1", "--host", help="Address to listen on."),
    port: int = typer.Option(8788, "--port", "-p", help="Port to listen on."),
    recipient: str | None = typer.Option(None, "--recipient", help="Name the provider goes by in flow rules."),
    agent: str = typer.Option("llm-client", "--agent", help="Name the agent goes by in flow rules."),
    block: bool = typer.Option(False, "--block", help="Block every refused flow instead of redacting it."),
    inspect_responses: bool = typer.Option(False, "--inspect-responses", help="Also judge non-streamed model responses."),
    style: str = typer.Option("placeholder", "--style", help="placeholder | token | masked | hash."),
    sign_key: str | None = typer.Option(None, "--sign-key", envvar="AGENTLEAK_EVIDENCE_KEY",
                                        help="Ed25519 key that signs every evidence entry."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Don't narrate decisions on stderr."),
) -> None:
    """Judge what an agent sends to its model: an OpenAI-compatible proxy.

    Point the client's base URL at it (OPENAI_BASE_URL=http://127.0.0.1:8788/v1).
    Each request's messages / input / prompt is checked against the same flow
    rules as `agentleak proxy`, with the provider as recipient: permitted
    content passes, refused values are redacted or tokenized, and denied flows
    get an OpenAI-shaped error. Streamed responses pass through unjudged.
    """
    from .defenses import RedactionStyle
    from .llm_proxy import run_llm_proxy

    style = {"mask": "masked"}.get(style, style)
    if style not in {x.value for x in RedactionStyle}:
        typer.secho(f"✗ unknown --style {style!r}", fg=typer.colors.RED)
        raise typer.Exit(code=2)
    if not _is_loopback_host(host):
        typer.secho(
            f"Note: listening on {host}. Anything that can reach this port can send "
            "requests through it with its own credentials.", fg=typer.colors.YELLOW,
        )
    flows: Any = None
    groups: dict[str, Any] = {}
    if config:
        try:
            cfg = Config.load(config)
        except Exception as exc:  # noqa: BLE001
            typer.secho(f"✗ could not load config: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=2) from exc
        flows = list(cfg.privacy_policy.flows)
        groups = dict(cfg.privacy_policy.groups)
    raise typer.Exit(code=run_llm_proxy(
        upstream, flows=flows, groups=groups, evidence=evidence, host=host, port=port,
        recipient=recipient or "", agent=agent, block_on_violation=block,
        inspect_responses=inspect_responses, style=style, sign_key=sign_key, verbose=not quiet,
    ))


@app.command()
def evidence(
    path: str = typer.Argument("agentleak-evidence.jsonl", help="Evidence log to read."),
    verify_only: bool = typer.Option(False, "--verify", help="Only check the chain; print nothing else."),
    fmt: str = typer.Option("text", "--format", "-f", help="text | json."),
    public_key: str | None = typer.Option(
        None, "--public-key", help="Also require every entry to be signed by this Ed25519 key.",
    ),
    keygen: str | None = typer.Option(
        None, "--keygen", help="Write a new signing key pair to this path (and PATH.pub), then exit.",
    ),
) -> None:
    """Verify and summarize a gateway evidence log.

    The log is hash-chained: each entry carries the hash of the one before it,
    so editing, removing or reordering any entry breaks every hash after it and
    this command says which one. That is tamper-evident, not tamper-proof —
    anyone who can write the file can rewrite the whole chain — but it is the
    property an auditor needs and a plain log does not have.
    """
    from .core.evidence import EvidenceLog
    from .core.evidence import verify as verify_chain

    if keygen:
        from .core.signing import generate_keypair

        try:
            private_file, public_file = generate_keypair(keygen)
        except RuntimeError as exc:
            typer.secho(f"✗ {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=2) from exc
        typer.secho(f"✓ private key → {private_file} (mode 600)", fg=typer.colors.GREEN)
        typer.secho(f"✓ public key  → {public_file}", fg=typer.colors.GREEN)
        typer.echo("Sign with:   agentleak proxy --sign-key " + str(private_file) + " -- …")
        typer.echo("Verify with: agentleak evidence LOG --public-key " + str(public_file))
        return

    key = None
    if public_key:
        from .core.signing import load_public_key

        try:
            key = load_public_key(public_key)
        except (RuntimeError, OSError, ValueError) as exc:
            typer.secho(f"✗ could not load public key: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=2) from exc

    result = verify_chain(path, public_key=key)
    if verify_only:
        if fmt == "json":
            typer.echo(json.dumps(result.to_dict(), indent=2))
        else:
            colour = typer.colors.GREEN if result.ok else typer.colors.RED
            typer.secho(result.detail, fg=colour)
        raise typer.Exit(code=0 if result.ok else 1)

    if not result.ok:
        typer.secho(f"⛔ {result.detail}", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    summary = EvidenceLog(path).summary()
    if fmt == "json":
        typer.echo(json.dumps(summary, indent=2))
        return

    typer.secho(f"✓ {result.detail}", fg=typer.colors.GREEN)
    typer.echo("")
    for action, count in summary["by_action"].items():
        colour = {
            "block": typer.colors.RED,
            "redact": typer.colors.YELLOW,
            "allow": typer.colors.GREEN,
        }.get(action, typer.colors.WHITE)
        typer.secho(f"  {action:<8}", fg=colour, nl=False)
        typer.echo(f" {count}")
    if summary["by_data_type"]:
        typer.echo("")
        typer.echo("Data types seen:")
        for data_type, count in summary["by_data_type"].items():
            typer.echo(f"  {data_type:<22} {count}")


def _is_loopback_host(host: str) -> bool:
    return str(host).strip().lower() in {"127.0.0.1", "localhost", "::1", "[::1]"}


@app.command()
def subjects(
    ledger: str = typer.Option(".agentleak/subjects.jsonl", "--ledger", help="Subject ledger to read."),
    forget: str | None = typer.Option(None, "--forget", help="Erase every secret attributed to this subject."),
    fmt: str = typer.Option("text", "--format", "-f", help="text | json."),
) -> None:
    """Inspect the cross-session subject ledger, or erase one subject from it.

    The ledger records which subject each secret belongs to, so a value written
    to memory while serving one person and repeated while serving another is
    caught — the failure per-run analysis cannot see. It holds salted
    fingerprints, never values.

    `--forget` exists because erasure is a right, not a feature request: a
    fingerprint of somebody's SIN is still about them.
    """
    from .core.subjects import SubjectLedger

    store = SubjectLedger(path=ledger)
    if not Path(ledger).exists():
        typer.secho(
            f"No ledger at {ledger}. Set privacy.subject_ledger in your config "
            "and give each run a subject to start one.",
            fg=typer.colors.YELLOW,
        )
        raise typer.Exit(code=1)

    if forget:
        removed = store.forget(forget)
        typer.secho(f"✓ erased {removed} secret(s) attributed to '{forget}'", fg=typer.colors.GREEN)
        return

    summary = store.summary()
    if fmt == "json":
        typer.echo(json.dumps(summary, indent=2))
        return
    typer.echo(f"{summary['secrets_tracked']} secret(s) tracked across {summary['subjects']} subject(s)")
    typer.echo("")
    for subject, count in summary["by_subject"].items():
        typer.echo(f"  {subject:<24} {count}")
    if summary["by_data_type"]:
        typer.echo("")
        typer.echo("By data type:")
        for data_type, count in summary["by_data_type"].items():
            typer.echo(f"  {data_type:<24} {count}")


@app.command()
def serve(
    host: str = typer.Option("127.0.0.1", "--host", help="Host to bind."),
    port: int = typer.Option(8000, "--port", "-p", help="Port to bind."),
    no_browser: bool = typer.Option(False, "--no-browser", help="Don't open a browser."),
    local: bool = typer.Option(
        False, "--local",
        help="Single-user workspace with no sign-in. Loopback only.",
    ),
) -> None:
    """Launch the local web GUI (pip install 'agentleak\\[gui]').

    `--local` skips the account entirely: a tool whose first claim is "100%
    local, nothing leaves your machine" should not open by asking for an email
    address. The workspace then belongs to whoever is at the machine, which is
    why it may only listen on loopback — the server refuses to start otherwise.
    """
    if local:
        if not _is_loopback_host(host):
            typer.secho(
                f"✗ --local cannot bind {host}. It serves an unauthenticated "
                "workspace, so it only listens on loopback. Drop --local to "
                "serve accounts, or bind 127.0.0.1.",
                fg=typer.colors.RED,
            )
            raise typer.Exit(code=2)
        if os.environ.get("AGENTLEAK_PUBLIC_MODE", "").strip().lower() in {"1", "true", "yes", "on"}:
            typer.secho(
                "✗ --local and AGENTLEAK_PUBLIC_MODE are mutually exclusive.",
                fg=typer.colors.RED,
            )
            raise typer.Exit(code=2)
        os.environ["AGENTLEAK_LOCAL_MODE"] = "1"

    try:
        from .web import run_server
    except Exception as exc:  # noqa: BLE001
        typer.secho(str(exc), fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
    typer.secho(f"AgentLeak GUI → http://{host}:{port}  (Ctrl+C to stop)", fg=typer.colors.GREEN)
    if local:
        typer.secho(
            "  local mode: no sign-in, single workspace, loopback only.",
            fg=typer.colors.YELLOW,
        )
    try:
        run_server(host=host, port=port, open_browser=not no_browser)
    except RuntimeError as exc:
        typer.secho(str(exc), fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc


# ----------------------------------------------------------------------
# run
# ----------------------------------------------------------------------
@app.command()
def run(
    config: str | None = typer.Option(None, "--config", "-c", help="Config file (honors detector/scoring settings)."),
    scenario: str | None = typer.Option(None, "--scenario", "-s", help="Run a built-in scenario (or 'all')."),
    pack: str | None = typer.Option(None, "--pack", help="Take --scenario from a bundled pack (e.g. agentleak_bench), or run 'all' of it."),
    trace: str | None = typer.Option(None, "--trace", "-t", help="Analyze a trace JSON file."),
    output: str | None = typer.Option(None, "--output", "-o", help="Report output directory."),
    fmt: str = typer.Option("json,html,markdown", "--format", "-f", help="Comma-separated formats."),
    fail_under: int | None = typer.Option(None, "--fail-under", help="Exit non-zero if a score is below this."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Less console output."),
) -> None:
    """Analyze a trace (or scenario) and write privacy reports."""
    cfg: Config | None = None
    if config:
        try:
            cfg = Config.load(config)
        except Exception as exc:  # noqa: BLE001
            typer.secho(f"✗ could not load config: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=2) from exc

    traces = _resolve_traces(trace, scenario, cfg, pack=pack)
    if not traces:
        typer.secho(
            "Nothing to run. Provide --trace, --scenario, or scenarios in --config.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=2)

    out_dir = output or (cfg.reports.output_dir if cfg else "reports")
    formats = [f for f in fmt.split(",") if f.strip()]
    runner = AgentLeakRunner(cfg)

    worst_blocked = False
    for _label, t, canaries in traces:
        result = runner.analyze(t, canary_set=canaries)
        if fail_under is not None:
            result.fail_below = fail_under
        written = write_reports(result, out_dir, formats, basename=result.run_id)
        if not quiet:
            _print_result(result, written)
        elif result.warnings:
            # Degradation warnings are safety-critical — surface them even in
            # --quiet mode so a degraded run is never mistaken for a clean pass.
            typer.secho(
                f"⚠ {result.run_id}: degraded run — a requested detection tier "
                "did not run; score may under-report leakage.",
                fg=typer.colors.BRIGHT_YELLOW, bold=True,
            )
            for w in result.warnings:
                typer.secho(f"  · {w}", fg=typer.colors.BRIGHT_YELLOW)
        worst_blocked = worst_blocked or result.blocked

    raise typer.Exit(code=1 if worst_blocked else 0)


# ----------------------------------------------------------------------
# report
# ----------------------------------------------------------------------
@app.command()
def report(
    input: str = typer.Option(..., "--input", "-i", help="A result.json produced by `run`."),
    fmt: str = typer.Option("html", "--format", "-f", help="Comma-separated formats to render."),
    output: str | None = typer.Option(None, "--output", "-o", help="Output directory."),
) -> None:
    """Re-render a saved JSON report into other formats."""
    try:
        with open(input, encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception as exc:  # noqa: BLE001
        typer.secho(f"✗ could not read report: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=2) from exc

    out_dir = output or os.path.dirname(os.path.abspath(input))
    basename = os.path.splitext(os.path.basename(input))[0]
    os.makedirs(out_dir, exist_ok=True)
    from .reporters import _EXTENSIONS  # local import: internal mapping

    for f in normalize_formats([x for x in fmt.split(",") if x.strip()]):
        content = render(data, f)
        path = os.path.join(out_dir, f"{basename}.{_EXTENSIONS[f]}")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(content)
        typer.secho(f"✓ {f}: {path}", fg=typer.colors.GREEN)


# ----------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------
def _canaries_of(meta: dict[str, object]) -> CanarySet | None:
    """A pack entry's ground-truth canaries, when it ships any."""
    raw = meta.get("canaries")
    if not isinstance(raw, dict):
        return None
    canaries = CanarySet.from_dict(raw)
    return None if canaries.is_empty() else canaries


def _resolve_traces(
    trace: str | None, scenario: str | None, cfg: Config | None, *, pack: str | None = None
) -> list[tuple[str, Trace, CanarySet | None]]:
    """Resolve what to analyze into ``(label, trace, canary_set)`` triples.

    Some packs ship ground truth alongside the trace (PrivacyLens states the
    exact facts that must not travel). That ground truth rides along as a
    canary set, because without it those scenarios score a false "Pass".
    """
    if trace:
        return [(trace, Trace.from_json_file(trace), None)]
    if pack:
        # A bundled research pack: the whole suite, or one scenario from it.
        # This is what makes the published benchmark one command away.
        from .scenarios.packs import expand_pack

        try:
            entries = expand_pack(pack)
        except (KeyError, FileNotFoundError, ValueError) as exc:
            raise typer.BadParameter(f"unknown pack: {pack}") from exc
        if not scenario or scenario == "all":
            return [
                (meta.get("origin_id") or meta.get("name", "?"), tr, _canaries_of(meta))
                for meta, tr in entries
            ]
        for meta, tr in entries:
            if scenario in (meta.get("origin_id"), meta.get("name")):
                return [(scenario, tr, _canaries_of(meta))]
        raise typer.BadParameter(f"scenario '{scenario}' not found in pack '{pack}'")
    if scenario:
        if scenario == "all":
            return [
                (s.id, load_example_trace(s.id), None)
                for s in list_scenarios() if s.example_trace
            ]
        return [(scenario, load_example_trace(scenario), None)]
    if cfg and cfg.scenarios:
        out: list[tuple[str, Trace, CanarySet | None]] = []
        for ref in cfg.scenarios:
            if ref.enabled:
                try:
                    out.append((ref.id, load_example_trace(ref.id), None))
                except (KeyError, ValueError):
                    typer.secho(f"! skipping unknown scenario '{ref.id}'", fg=typer.colors.YELLOW)
        return out
    return []


def _print_result(result: AnalysisResult, written: dict[str, str]) -> None:
    data = result.to_dict()
    verdict_color = _VERDICT_COLORS.get(result.verdict, typer.colors.WHITE)

    typer.echo("")
    typer.secho("AgentLeak Privacy Report (AgentRisk scoring)", bold=True)
    typer.echo(f"Agent: {result.agent_name} · run: {result.run_id} · events: {result.event_count}")
    typer.echo("")
    typer.secho(
        f"Risk Index: {data['risk_index']:.3f}   {result.verdict}   "
        f"(privacy {result.privacy_score}/100)",
        fg=verdict_color, bold=True,
    )
    lp = data["summary"]["level_profile"]
    s = data["summary"]
    typer.echo(
        f"WSL {data['wsl']} / ρ_S {data['rho_s']}  ·  "
        f"{s['leaked_secrets']} of {s['vault_secrets']} secrets leaked  "
        f"(L4 {lp['L4']}, L3 {lp['L3']}, L2 {lp['L2']}, L1 {lp['L1']})"
    )
    # State the strength of this result: a Pass from regex alone is a weaker
    # claim than a Pass from the full hybrid pipeline, and the reader should
    # not have to guess which one they got.
    det = data.get("detection", {})
    if det:
        tiers = ", ".join(det.get("tiers", []))
        typer.secho(
            f"Detection: {det.get('mode', '?')} mode · tiers: {tiers}",
            fg=typer.colors.BRIGHT_BLACK,
        )
        if det.get("mode") == "fast":
            typer.secho(
                "  (regex only — add Presidio with --mode standard, or the "
                "LLM-judge with --mode hybrid, for deeper coverage)",
                fg=typer.colors.BRIGHT_BLACK,
            )
    cs = data.get("compliance", {}).get("summary")
    if cs:
        color = typer.colors.GREEN if cs["non_compliant"] == 0 else typer.colors.BRIGHT_YELLOW
        typer.secho(
            f"Compliance: {cs['compliant']}/{cs['total']} frameworks clear "
            f"({cs['controls_at_risk']} control(s) at risk)",
            fg=color,
        )
    if result.warnings:
        typer.echo("")
        typer.secho(
            "⚠ Degraded run — a requested detection tier did not run. "
            "This score may under-report leakage; do not read it as a clean pass.",
            fg=typer.colors.BRIGHT_YELLOW, bold=True,
        )
        for w in result.warnings:
            typer.secho(f"  · {w}", fg=typer.colors.BRIGHT_YELLOW)

    policy = data.get("privacy_policy", {})
    if policy.get("enabled"):
        color = typer.colors.GREEN if policy.get("passed") else typer.colors.RED
        status = "passed" if policy.get("passed") else "failed"
        typer.secho(
            f"Privacy policy: {status} · {len(policy.get('violations', []))} violation(s)",
            fg=color,
        )
        for violation in policy.get("violations", []):
            typer.echo(f"  - {violation['rule']}: {violation['message']}")
        # A flow violation names a recipient and a purpose, which is what the
        # operator changes. Summarised in the message, listed in full here.
        for decision in policy.get("flows", {}).get("violations", []):
            recipient = decision.get("recipient") or "?"
            purpose = decision.get("purpose") or "no declared purpose"
            typer.echo(
                f"      {decision['data_type']} -> {recipient} ({purpose})"
            )

    cross = data.get("cross_session") or {}
    if cross.get("enabled") and not cross.get("passed"):
        breaches = cross["cross_subject_disclosures"]
        typer.secho(
            f"Cross-session: {len(breaches)} disclosure(s) of another subject's data",
            fg=typer.colors.RED,
        )
        for breach in breaches:
            typer.echo(
                f"  - {breach['data_type']}: belongs to '{breach['owner']}', "
                f"disclosed on {breach['channel']} while serving "
                f"'{breach['disclosed_to']}'"
            )

    if data["channel_risks"]:
        typer.echo("")
        typer.echo("Risk by channel:")
        for cr in data["channel_risks"]:
            color = _LEVEL_COLORS.get(cr["level"], typer.colors.WHITE)
            typer.echo("  " + f"{cr['channel']:<22} ", nl=False)
            typer.secho(f"{cr['level_label']:<4}", fg=color, nl=False)
            typer.echo(f" RI {cr['ri']:.3f}  {cr['finding_count']} finding(s)")

    insight = _console_insight(data)
    if insight:
        typer.echo("")
        typer.secho("Key insight: ", fg=typer.colors.CYAN, bold=True, nl=False)
        typer.echo(insight)

    if result.blocked:
        typer.echo("")
        typer.secho("⛔ Blocked — this run would fail a CI privacy gate.", fg=typer.colors.RED, bold=True)

    if written:
        typer.echo("")
        for f, path in written.items():
            typer.secho(f"✓ {f:<8} {path}", fg=typer.colors.GREEN)


def _console_insight(data: dict) -> str | None:
    levels = {cr["channel"]: cr["level"] for cr in data.get("channel_risks", [])}
    output_level = levels.get("final_output", "none")
    internal = [c for c, lvl in levels.items() if c in _INTERNAL_CHANNELS and lvl != "none"]
    if output_level in {"none", "low"} and internal:
        return (
            "the final answer appears safe, but sensitive data leaked through "
            f"internal channels ({', '.join(internal)})."
        )
    return None


# ----------------------------------------------------------------------
# history
# ----------------------------------------------------------------------
@app.command()
def history(
    project: str = typer.Argument(..., help="Project name."),
    limit: int = typer.Option(50, "--limit", "-n", help="Max runs to show."),
    db_path: str | None = typer.Option(None, "--db", help="Path to agentleak.db (default: ~/.agentleak/)."),
) -> None:
    """Show the score progression history for a project."""
    import datetime

    from .core.store import Store

    store = Store(db_path) if db_path else Store()
    proj = store.get_project_by_name(project)
    if not proj:
        typer.secho(f"✗ Project '{project}' not found.", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    runs = store.run_history(proj["id"], limit=limit)
    if not runs:
        typer.secho(f"No runs found for project '{project}'.", fg=typer.colors.YELLOW)
        return

    typer.secho(f"\nHistory — {project}  ({len(runs)} runs)\n", bold=True)
    typer.echo(
        f"  {'#':<4}  {'Run ID':<18}  {'Date':<20}  {'Score':>5}  {'Δ':>5}  "
        f"{'RI':>6}  {'ΔRI':>7}  {'Verdict':<18}  Label"
    )
    typer.echo("  " + "─" * 95)
    for r in runs:
        d_score = r["delta_score"]
        d_ri = r["delta_ri"]
        delta_str = f"{d_score:>+5}" if d_score is not None else f"{'—':>5}"
        dri_str = f"{d_ri:>+.3f}" if d_ri is not None else f"{'—':>7}"
        dt = datetime.datetime.fromtimestamp(r["created_at"]).strftime("%Y-%m-%d %H:%M")
        blocked_flag = " ⛔" if r["blocked"] else ""
        label = r.get("label") or ""
        score_color = (
            typer.colors.GREEN if r["privacy_score"] >= 80
            else typer.colors.YELLOW if r["privacy_score"] >= 50
            else typer.colors.RED
        )
        delta_color = (
            typer.colors.GREEN if (d_score or 0) > 0
            else typer.colors.RED if (d_score or 0) < 0
            else typer.colors.WHITE
        )
        typer.echo(f"  {r['rank']:<4}  {r['id']:<18}  {dt:<20}  ", nl=False)
        typer.secho(f"{r['privacy_score']:>5}", fg=score_color, nl=False)
        typer.echo("  ", nl=False)
        typer.secho(delta_str, fg=delta_color, nl=False)
        typer.echo(f"  {r['risk_index']:>6.3f}  {dri_str:>7}  {r['verdict']:<18}{blocked_flag}  {label}")

    if len(runs) > 1:
        first, last = runs[0], runs[-1]
        total = last["privacy_score"] - first["privacy_score"]
        total_color = typer.colors.GREEN if total > 0 else typer.colors.RED if total < 0 else typer.colors.WHITE
        best = max(runs, key=lambda r: r["privacy_score"])
        typer.echo("")
        typer.echo("  Total improvement : ", nl=False)
        typer.secho(f"{total:+d} pts", fg=total_color, bold=True)
        typer.echo(f"  Best run          : {best['id']}  ({best['privacy_score']}/100)")
        typer.echo(f"  Blocked runs      : {sum(1 for r in runs if r['blocked'])}/{len(runs)}")
    typer.echo("")


# ----------------------------------------------------------------------
# compare
# ----------------------------------------------------------------------
@app.command()
def compare(
    run_a: str = typer.Argument(..., help="First run ID (baseline)."),
    run_b: str = typer.Argument(..., help="Second run ID (comparison)."),
    db_path: str | None = typer.Option(None, "--db", help="Path to agentleak.db."),
) -> None:
    """Compare two runs side by side and show score/RI/compliance deltas."""
    from typing import Any as _Any

    from .core.store import Store

    store = Store(db_path) if db_path else Store()
    result = store.compare_runs(run_a, run_b)
    if result is None:
        typer.secho("✗ One or both run IDs not found.", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    a, b, diff = result["run_a"], result["run_b"], result["diff"]

    typer.secho("\nRun comparison", bold=True)
    typer.echo(f"  A (baseline) : {a['id']}  {a.get('label') or ''}".rstrip())
    typer.echo(f"  B (current)  : {b['id']}  {b.get('label') or ''}".rstrip())
    typer.echo("")

    typer.echo(f"  {'Metric':<24}  {'A':>8}  {'B':>8}  {'Delta':>8}")
    typer.echo("  " + "─" * 56)

    def _row(name: str, val_a: _Any, val_b: _Any, delta: _Any, *, invert: bool = False) -> None:
        if delta is None:
            delta_str, delta_color = "—", typer.colors.WHITE
        else:
            delta_str = f"{delta:+.3f}" if isinstance(delta, float) else f"{delta:+d}"
            positive_is_good = (delta > 0) ^ invert
            delta_color = (
                typer.colors.GREEN if positive_is_good
                else typer.colors.RED if delta != 0
                else typer.colors.WHITE
            )
        va = f"{val_a:.3f}" if isinstance(val_a, float) else str(val_a)
        vb = f"{val_b:.3f}" if isinstance(val_b, float) else str(val_b)
        typer.echo(f"  {name:<24}  {va:>8}  {vb:>8}  ", nl=False)
        typer.secho(f"{delta_str:>8}", fg=delta_color)

    _row("Privacy score", a["privacy_score"], b["privacy_score"], diff["delta_score"])
    _row("Risk Index (RI)", a["risk_index"], b["risk_index"], diff["delta_ri"], invert=True)
    _row("Leaked secrets", a["leaked_secrets"], b["leaked_secrets"], diff["delta_leaked"], invert=True)
    total_a = a.get("report", {}).get("summary", {}).get("total_findings", 0)
    total_b = b.get("report", {}).get("summary", {}).get("total_findings", 0)
    _row("Total findings", total_a, total_b, diff["delta_findings"], invert=True)
    _row("Blocked", "yes" if a["blocked"] else "no", "yes" if b["blocked"] else "no", None)

    fws = diff.get("frameworks", [])
    if fws:
        typer.echo("")
        typer.secho("  Compliance frameworks:", bold=True)
        for fw in fws:
            icon = {"fixed": "✓", "regressed": "✗", "same": " "}.get(fw["change"], " ")
            color = {"fixed": typer.colors.GREEN, "regressed": typer.colors.RED}.get(fw["change"])
            line = f"  {icon} [{fw['id']:<14}]  {fw['before']:<12} → {fw['after']}"
            if color:
                typer.secho(line, fg=color)
            else:
                typer.echo(line)

    typer.echo("")
    direction = diff.get("score_direction", "unchanged")
    dcolor = {"improved": typer.colors.GREEN, "regressed": typer.colors.RED}.get(direction, typer.colors.WHITE)
    typer.secho(f"  Overall: {direction.upper()}", fg=dcolor, bold=True)
    if diff.get("blocked_resolved"):
        typer.secho("  Blocker resolved — run B passes the privacy gate.", fg=typer.colors.GREEN)
    typer.echo("")


def main() -> None:
    app()


if __name__ == "__main__":  # pragma: no cover
    main()
