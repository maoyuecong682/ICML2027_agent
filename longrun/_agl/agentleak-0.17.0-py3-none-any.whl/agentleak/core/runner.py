# SPDX-FileCopyrightText: 2026 AgentLeak contributors
# SPDX-License-Identifier: MIT
"""The orchestrator: run detectors over a trace, score the findings with
AgentRisk, and produce an :class:`AnalysisResult`.

This is the single seam everything else (CLI, SDK, integrations) goes through.
"""

from __future__ import annotations

import os
from typing import Any

from ..detectors import build_detectors
from .agentrisk import DEFAULT_WEIGHTS
from .canary import CanarySet
from .coalesce import canonical_form, coalesce_findings
from .config import Config
from .detector import Detector, Finding
from .pipeline import DetectionMode, HybridPipeline
from .privacy_policy import evaluate_privacy_policy
from .report import AnalysisResult
from .scoring import score_findings
from .subjects import SubjectLedger, evaluate_subjects
from .trace import Trace
from .transforms import describe, find_obscured_copies


def _build_pipeline(
    config: Config | None, detectors: list[Detector]
) -> tuple[HybridPipeline, list[str]]:
    """Construct a HybridPipeline from optional config.

    Returns the pipeline and a list of degradation warnings: when the selected
    ``mode`` asks for a tier that cannot run (missing dependency or API key), we
    surface it loudly rather than silently scoring with fewer tiers. A gate that
    turns "I couldn't check" into a green pass is worse than one that errors.
    """
    warnings: list[str] = []
    if config is None:
        return HybridPipeline(detectors, mode=DetectionMode.FAST), warnings

    det_cfg = config.detection
    mode = DetectionMode(det_cfg.mode) if det_cfg.mode else DetectionMode.FAST
    wants_presidio = mode in (DetectionMode.STANDARD, DetectionMode.HYBRID)
    wants_llm = mode in (DetectionMode.HYBRID, DetectionMode.LLM_ONLY)

    # Tier 2b: Presidio (optional extra)
    presidio = None
    if det_cfg.presidio.enabled:
        try:
            from ..detectors.presidio_detector import PresidioDetector
            presidio = PresidioDetector(score_threshold=det_cfg.presidio.score_threshold)
        except Exception as exc:
            warnings.append(
                "Presidio tier requested but could not load "
                f"({exc.__class__.__name__}); install 'agentleak[presidio]'. "
                "Entity detection (names, locations, etc.) did NOT run."
            )
    if wants_presidio and presidio is None:
        warnings.append(
            f"Detection mode '{mode.value}' includes Presidio, but it is not "
            "active; results rely on the regex tier only."
        )

    # Tier 3: LLM-judge (requires API key)
    llm_judge = None
    if det_cfg.llm_judge.enabled:
        api_key = os.environ.get(det_cfg.llm_judge.api_key_env, "")
        if not api_key:
            warnings.append(
                f"LLM-judge tier requested but ${det_cfg.llm_judge.api_key_env} "
                "is not set; semantic detection did NOT run. Paraphrased or "
                "unseen sensitive values may be missed."
            )
        else:
            try:
                from ..detectors.llm_judge import LLMJudgeDetector
                llm_judge = LLMJudgeDetector(
                    base_url=det_cfg.llm_judge.base_url,
                    model=det_cfg.llm_judge.model,
                    api_key=api_key,
                    threshold=det_cfg.llm_judge.threshold,
                    timeout=det_cfg.llm_judge.timeout,
                )
            except Exception as exc:
                warnings.append(
                    "LLM-judge tier requested but could not initialise "
                    f"({exc.__class__.__name__}); semantic detection did NOT run."
                )
    if wants_llm and llm_judge is None and det_cfg.llm_judge.enabled and os.environ.get(
        det_cfg.llm_judge.api_key_env, ""
    ):
        # Enabled + keyed but still absent — construction failed above.
        pass
    elif wants_llm and llm_judge is None and not det_cfg.llm_judge.enabled:
        warnings.append(
            f"Detection mode '{mode.value}' includes the LLM-judge, but no judge "
            "is configured (detection.llm_judge.enabled is false)."
        )

    pipeline = HybridPipeline(
        detectors,
        mode=mode,
        llm_judge=llm_judge,
        presidio=presidio,
        level_overrides=config.scoring.level_overrides if config else {},
    )
    return pipeline, warnings


class AgentLeakRunner:
    """Analyze traces for sensitive-data leakage, scored with AgentRisk.

    With no config, every built-in detector runs over every channel — handy for
    quick SDK use. Pass a :class:`Config` to honor ``agentleak.yaml`` toggles,
    channel filters, custom detectors, severity-level overrides, the audited
    vault scope, and scoring thresholds.
    """

    def __init__(self, config: Config | None = None) -> None:
        self.config = config
        if config is None:
            raw_detectors: list[Detector] = build_detectors(None, None)
            self._channels: set[str] | None = None
            self._redact = True
            self._block_on_critical = True
            self._fail_below = 40
            self._project = "agentleak-project"
            self._weights: tuple[int, ...] = DEFAULT_WEIGHTS
            self._level_overrides: dict[str, int] = {}
            self._vault: Any = None
            self._scope_def: str | None = None
            self._privacy_policy: Any = None
            self._subject_ledger: SubjectLedger | None = None
        else:
            raw_detectors = build_detectors(
                config.detectors.as_dict(), config.custom_rules_raw()
            )
            self._channels = config.enabled_channels()
            self._redact = config.privacy.redact_values
            self._block_on_critical = config.scoring.block_on_critical
            self._fail_below = config.scoring.fail_below
            self._project = config.project.name
            self._weights = tuple(config.scoring.weights) or DEFAULT_WEIGHTS
            self._level_overrides = dict(config.scoring.level_overrides)
            self._vault, self._scope_def = config.vault_spec()
            self._privacy_policy = config.privacy_policy
            # Cross-session checking is opt-in: without a declared ledger the
            # runner has no project root to write one into, and inventing a
            # location that quietly accumulates subject data would be the wrong
            # default for a tool about not accumulating subject data.
            ledger_path = getattr(config.privacy, "subject_ledger", "")
            self._subject_ledger = SubjectLedger(path=ledger_path) if ledger_path else None

        self.detectors = raw_detectors
        self._pipeline, self._warnings = _build_pipeline(config, raw_detectors)

    def analyze(
        self,
        trace: Trace,
        *,
        vault: Any = None,
        scope_def: str | None = None,
        canary_set: CanarySet | None = None,
        subject_ledger: SubjectLedger | None = None,
        subject: str = "",
    ) -> AnalysisResult:
        """Analyze a trace. An explicit ``vault`` (per-level counts, a list of
        secrets, or a raw ρ_S) overrides the config and the observed-reachable
        default for the AgentRisk denominator.

        Pass a :class:`~agentleak.core.canary.CanarySet` to enable exact canary
        matching in addition to the regular detector chain.
        """
        findings: list[Finding] = []
        counter = 0

        for event in trace.events:
            channel = event.channel_value
            if self._channels is not None and channel not in self._channels:
                continue

            text = event.searchable_text
            if not text:
                continue

            event_findings = self._pipeline.run_event(
                text=text,
                event_id=event.event_id,
                run_id=trace.run_id,
                channel=channel,
                source=event.source,
                target=event.target,
                metadata=dict(event.metadata),
                canary_set=canary_set,
                finding_counter=counter,
            )
            counter += len(event_findings)
            findings.extend(event_findings)

        # Copies of an exposed value that no plaintext detector can read:
        # reversed, ROT13-rotated, or split across messages to one recipient.
        findings = _add_obscured_copies(trace, findings, self._channels, counter)

        # One identity per secret before anything counts them. Detectors
        # disagree on where an entity ends, and AgentRisk keys a secret on the
        # matched string, so overlapping matches would enter the vault as
        # separate secrets and inflate both WSL and rho_S.
        findings = coalesce_findings(findings)

        # Where each value entered the run and every node it passed through,
        # so a flow rule can judge a leak by its source, not only its last hop.
        _annotate_provenance(trace, findings)

        # Stable, readable ordering: highest severity level first, then confidence.
        findings.sort(key=lambda f: (-f.level, -f.confidence))

        score = score_findings(
            findings,
            weights=self._weights,
            level_overrides=self._level_overrides,
            vault=vault if vault is not None else self._vault,
            scope_def=scope_def or self._scope_def,
        )

        # Cross-session attribution, after scoring so it never moves the score.
        # A secret that belongs to another subject still leaked in this trace
        # and AgentRisk already counts it; what this adds is whose it was.
        ledger = subject_ledger if subject_ledger is not None else self._subject_ledger
        subject_evaluation = evaluate_subjects(
            ledger, findings, trace=trace, subject=subject
        )

        selected_vault = vault if vault is not None else self._vault
        policy_evaluation = evaluate_privacy_policy(
            self._privacy_policy,
            findings,
            risk_index=score.risk_index,
            explicit_vault=selected_vault is not None,
            subject_evaluation=subject_evaluation,
        )

        return AnalysisResult(
            run_id=trace.run_id,
            agent_name=trace.agent_name,
            scenario_id=trace.scenario_id,
            score=score,
            findings=findings,
            project_name=self._project,
            redact_values=self._redact,
            block_on_critical=self._block_on_critical,
            fail_below=self._fail_below,
            policy_evaluation=policy_evaluation,
            subject_evaluation=subject_evaluation,
            task_success=trace.task_success,
            warnings=list(self._warnings),
            detection_mode=self._pipeline.mode.value,
            tiers=self._pipeline.finding_tiers,
            event_count=len(trace.events),
            events=[
                {
                    "event_id": e.event_id,
                    "channel": e.channel_value,
                    "source": e.source,
                    "target": e.target,
                    "agent": trace.agent_name,
                }
                for e in trace.events
            ],
        )


# Types whose value names a category rather than identifying anyone; anchoring
# on them would report every later mention of the word.
_NOT_ANCHORS = frozenset({"employment_status", "internal_note"})


def _annotate_provenance(trace: Trace, findings: list[Finding]) -> None:
    """Set ``metadata["origin"]`` and ``metadata["path"]`` on each finding.

    The origin is the sender of the first event, in trace order, whose text
    holds the value; the path is every node that held it after, in order.
    An origin already set by the caller (an SDK event's own metadata) wins.
    """
    events = [e for e in trace.events if e.searchable_text]
    texts = [canonical_form(e.searchable_text) for e in events]
    cache: dict[str, tuple[str, tuple[str, ...]]] = {}
    for finding in findings:
        key = canonical_form(finding.matched_value)
        if not key:
            continue
        if key not in cache:
            path: list[str] = []
            for event, text in zip(events, texts, strict=True):
                if key not in text:
                    continue
                for node in (event.source or "", event.target or ""):
                    if node and (not path or path[-1] != node):
                        path.append(node)
            cache[key] = (path[0] if path else "", tuple(path))
        origin, path_nodes = cache[key]
        finding.metadata.setdefault("origin", origin)
        finding.metadata.setdefault("path", list(path_nodes))


def _alnum_key(value: str) -> str:
    return "".join(ch for ch in value.casefold() if ch.isalnum())


def _add_obscured_copies(
    trace: Trace,
    findings: list[Finding],
    channels: set[str] | None,
    counter: int,
) -> list[Finding]:
    """Findings for obscured copies of values this trace already exposed."""
    events = [
        e for e in trace.events
        if e.searchable_text and (channels is None or e.channel_value in channels)
    ]
    if len(events) < 2 or not findings:
        return findings
    unique_ids = len({e.event_id for e in events}) == len(events)
    templates: dict[str, Finding] = {}
    for f in findings:
        if f.data_type in _NOT_ANCHORS:
            continue
        key = canonical_form(f.matched_value)
        if key not in templates or f.level > templates[key].level:
            templates[key] = f
    copies = find_obscured_copies(
        [(e.searchable_text, e.target, e.channel_value) for e in events],
        [t.matched_value for t in templates.values()],
    )
    if not copies:
        return findings

    out = list(findings)
    for copy in copies:
        event = events[copy.event_index]
        template = templates[canonical_form(copy.value)]
        if copy.transform == "reversed" and unique_ids:
            # A reversed SIN still looks like a SIN, so a detector may already
            # have reported it as a *different* one. It is this one, reversed.
            reversed_canon = canonical_form(copy.value)[::-1]
            out = [
                f for f in out
                if not (f.event_id == event.event_id
                        and canonical_form(f.matched_value) == reversed_canon)
            ]
        if unique_ids:
            # A detector may already have read the decoded copy in a different
            # format (4111111111111111 for 4111 1111 1111 1111): same secret,
            # so the anchored finding replaces it rather than counting twice.
            target_alnum = _alnum_key(copy.value)
            out = [
                f for f in out
                if not (f.event_id == event.event_id
                        and f.metadata.get("transform")
                        and f.data_type == template.data_type
                        and _alnum_key(f.matched_value) == target_alnum)
            ]
        counter += 1
        fragments = [events[i].event_id for i in copy.fragments]
        out.append(Finding(
            finding_id=f"finding_{counter:03d}",
            run_id=trace.run_id,
            event_id=event.event_id,
            channel=event.channel_value,
            data_type=template.data_type,
            severity=template.severity,
            confidence=0.8 if copy.transform == "split" else 0.85,
            matched_value=template.matched_value,
            redacted_value=template.redacted_value,
            detector=template.detector,
            recommendation=(
                f"This {template.data_type.replace('_', ' ')} was {describe(copy.transform)}"
                + (f" ({', '.join(fragments)})" if fragments else "")
                + "; obscuring a value does not stop the recipient reading it. "
                + template.recommendation
            ).strip(),
            source=event.source,
            target=event.target,
            level=template.level,
            metadata={
                **dict(event.metadata),
                "tier": f"anchored:{copy.transform}",
                "transform": copy.transform,
                **({"fragments": fragments} if fragments else {}),
            },
        ))
    return out


def analyze(trace: Trace, config: Config | None = None, **kwargs: Any) -> AnalysisResult:
    """Functional shortcut for ``AgentLeakRunner(config).analyze(trace)``."""
    return AgentLeakRunner(config).analyze(trace, **kwargs)
