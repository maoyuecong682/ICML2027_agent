# SPDX-FileCopyrightText: 2026 AgentLeak contributors
# SPDX-License-Identifier: MIT
"""Configuration model for ``agentleak.yaml`` (spec section 10).

Validated with Pydantic so ``agentleak validate`` can give precise errors.
"""

from __future__ import annotations

from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .trace import CHANNELS


class ProjectConfig(BaseModel):
    name: str = "agentleak-project"
    description: str = ""


class AgentConfig(BaseModel):
    name: str = "agent"
    type: str = "generic"
    endpoint: str | None = None


class ScenarioRef(BaseModel):
    id: str
    enabled: bool = True


class DetectorToggles(BaseModel):
    model_config = ConfigDict(extra="allow")
    pii: bool = True
    secrets: bool = True
    healthcare: bool = True
    finance: bool = False
    hr: bool = False
    # Key-name-aware detection: flags values under sensitive field names even
    # when no dictionary recognises the value. On by default — it closes the
    # main recall gap on realistic, unseen PII/PHI.
    keyname: bool = True

    def as_dict(self) -> dict[str, bool]:
        return self.model_dump()


class ScoringConfig(BaseModel):
    fail_below: int = 40
    conditional_below: int = 70
    block_on_critical: bool = True
    # AgentRisk four-tier severity weights w(L1..L4). Only ratios matter
    # (scale-invariant), so [1,2,3,4] and [2,4,6,8] are equivalent.
    weights: list[int] = Field(default_factory=lambda: [1, 2, 3, 4])
    # Per-data-type severity-level overrides (a deployment's data-classification
    # policy), e.g. {"person_name": 3} to treat names as more sensitive.
    level_overrides: dict[str, int] = Field(default_factory=dict)

    @field_validator("weights")
    @classmethod
    def validate_weights(cls, weights: list[int]) -> list[int]:
        if len(weights) != 4 or any(weight <= 0 for weight in weights):
            raise ValueError("weights must contain four strictly positive integers (L1..L4)")
        return weights


class VaultConfig(BaseModel):
    """Optional audited-vault scope: the denominator ρ_S for the Risk Index.

    Provide either per-level counts (``levels``) or a raw ``rho_s``. When unset,
    AgentRisk falls back to the observed reachable set (everything detected).
    """

    levels: dict[int, int] = Field(default_factory=dict)
    rho_s: int | None = None
    scope_def: str | None = None

    def is_set(self) -> bool:
        return bool(self.levels) or self.rho_s is not None


class LLMProviderConfig(BaseModel):
    """LLM provider used for live agent runs (``agentleak run --live``)."""

    provider: str = "openrouter"
    base_url: str = "https://openrouter.ai/api/v1"
    model: str = "openai/gpt-4o-mini"
    api_key_env: str = "OPENROUTER_API_KEY"
    temperature: float = 0.2
    timeout: float = 60.0


class ReportsConfig(BaseModel):
    output_dir: str = "reports"
    formats: list[str] = Field(default_factory=lambda: ["json", "html", "markdown"])


class PrivacyConfig(BaseModel):
    redact_values: bool = True
    store_raw_traces: bool = False
    #: Path to the cross-session subject ledger. Empty disables the check.
    #:
    #: Opt-in on purpose. The ledger remembers which subject each secret
    #: belongs to, so enabling it by default would mean a privacy tool quietly
    #: starting to accumulate data about people in a location nobody chose.
    #: It stores salted fingerprints rather than values, and
    #: `agentleak subjects --forget` erases one subject's entries.
    subject_ledger: str = ""


class CustomDetectorConfig(BaseModel):
    model_config = ConfigDict(extra="allow")
    name: str
    pattern: str
    severity: str = "medium"
    data_type: str = "custom"
    confidence: float = 0.9


class LLMJudgeConfig(BaseModel):
    """Configuration for the Tier-3 LLM-as-Judge semantic detector."""

    enabled: bool = False
    base_url: str = ""
    model: str = ""
    api_key_env: str = "OPENAI_API_KEY"
    threshold: float = 0.72
    timeout: float = 30.0


class PresidioConfig(BaseModel):
    """Configuration for the Tier-2b Presidio detector (extra required)."""

    enabled: bool = False
    score_threshold: float = 0.5


class DetectionConfig(BaseModel):
    """Controls the hybrid detection pipeline (Tiers 1–3)."""

    mode: str = "fast"  # fast | standard | hybrid | llm_only
    llm_judge: LLMJudgeConfig = Field(default_factory=LLMJudgeConfig)
    presidio: PresidioConfig = Field(default_factory=PresidioConfig)


class PolicyGateConfig(BaseModel):
    """Compliance gates evaluated after every selftest / CI run."""

    # List of framework IDs that must pass; any failure → passed=False.
    fail_on: list[str] = Field(default_factory=list)
    # When True, block on ANY non-compliant framework.
    fail_on_any: bool = False


class PrivacyPolicyConfig(BaseModel):
    """Simple declarative assertions applied to every runtime trace."""

    max_risk_index: float | None = Field(default=None, ge=0.0, le=1.0)
    max_findings: int | None = Field(default=None, ge=0)
    forbid_levels: list[int] = Field(default_factory=list)
    forbid_channels: list[str] = Field(default_factory=list)
    forbid_data_types: list[str] = Field(default_factory=list)
    require_explicit_vault: bool = False

    # Contextual-integrity rules: which flows of which data are appropriate.
    # Every assertion above judges data *presence* — this type, that channel,
    # that many findings. None of them can express the difference between a SIN
    # reaching a KYC vendor for an identity check and the same SIN reaching an
    # analytics sink, which is the difference privacy law actually turns on.
    # See agentleak.core.contextual_integrity for the rule grammar.
    flows: list[dict[str, Any]] = Field(default_factory=list)
    #: Named sets of senders, recipients or data types for flow rules:
    #: ``third-parties: [analytics, crm-x]`` lets a rule say
    #: ``to: group:third-parties``. Built-in data-type groups (credentials,
    #: health, financial, government_ids, contact) need no definition.
    groups: dict[str, list[str]] = Field(default_factory=dict)
    #: Fail the gate when a run discloses another subject's data. Needs
    #: `privacy.subject_ledger` and a subject on each run; without both it has
    #: nothing to check and stays silent rather than passing vacuously.
    forbid_cross_subject: bool = False

    @model_validator(mode="after")
    def validate_flows(self) -> PrivacyPolicyConfig:
        # Parse eagerly so a malformed rule — or a group nobody defined — fails
        # at config load, where the line number is, rather than silently
        # governing nothing at run time.
        from .contextual_integrity import FlowRule

        for rule in self.flows:
            FlowRule.from_mapping(rule, self.groups)
        return self

    @field_validator("forbid_levels")
    @classmethod
    def validate_forbid_levels(cls, levels: list[int]) -> list[int]:
        if any(level not in (1, 2, 3, 4) for level in levels):
            raise ValueError("forbid_levels values must be between 1 and 4")
        return list(dict.fromkeys(levels))

    @field_validator("forbid_channels")
    @classmethod
    def validate_forbid_channels(cls, channels: list[str]) -> list[str]:
        unknown = [channel for channel in channels if channel not in CHANNELS]
        if unknown:
            raise ValueError(f"unknown privacy policy channel(s): {', '.join(unknown)}")
        return list(dict.fromkeys(channels))


class DefenseConfig(BaseModel):
    """Runtime sanitizer applied before findings are stored/returned."""

    enabled: bool = False
    # Redaction style: placeholder | asterisk | masked | hash | category | remove
    style: str = "placeholder"
    # Channels to sanitize (empty = all leak channels).
    channels: list[str] = Field(default_factory=list)


class Config(BaseModel):
    """Top-level AgentLeak configuration."""

    model_config = ConfigDict(extra="allow")

    project: ProjectConfig = Field(default_factory=ProjectConfig)
    agent: AgentConfig = Field(default_factory=AgentConfig)
    scenarios: list[ScenarioRef] = Field(default_factory=list)
    channels: list[str] = Field(default_factory=lambda: list(CHANNELS))
    detectors: DetectorToggles = Field(default_factory=DetectorToggles)
    scoring: ScoringConfig = Field(default_factory=ScoringConfig)
    reports: ReportsConfig = Field(default_factory=ReportsConfig)
    privacy: PrivacyConfig = Field(default_factory=PrivacyConfig)
    vault: VaultConfig = Field(default_factory=VaultConfig)
    custom_detectors: list[CustomDetectorConfig] = Field(default_factory=list)
    llm: LLMProviderConfig = Field(default_factory=LLMProviderConfig)
    detection: DetectionConfig = Field(default_factory=DetectionConfig)
    defense: DefenseConfig = Field(default_factory=DefenseConfig)
    policy_gate: PolicyGateConfig = Field(default_factory=PolicyGateConfig)
    privacy_policy: PrivacyPolicyConfig = Field(default_factory=PrivacyPolicyConfig)

    # ------------------------------------------------------------------
    @classmethod
    def load(cls, path: str) -> Config:
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        return cls.model_validate(data)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Config:
        return cls.model_validate(data or {})

    def enabled_channels(self) -> set[str]:
        return set(self.channels)

    def custom_rules_raw(self) -> list[dict[str, Any]]:
        return [c.model_dump() for c in self.custom_detectors]

    def vault_spec(self) -> tuple[Any, str | None]:
        """Return (vault_spec, scope_def) for the AgentRisk denominator."""
        if not self.vault.is_set():
            return None, None
        if self.vault.rho_s is not None:
            return self.vault.rho_s, self.vault.scope_def
        return dict(self.vault.levels), self.vault.scope_def


DEFAULT_CONFIG_YAML = """\
# yaml-language-server: $schema=https://www.agentleak.org/api/schemas/config
project:
  name: my-agent-test
  description: Privacy leakage test for my AI agent

agent:
  name: my-agent
  type: generic
  endpoint: null

# LLM provider for live agent runs (agentleak run --live).
# OpenRouter is the default — set OPENROUTER_API_KEY in your .env.
# To switch models, change `model` below. Examples:
#   openai/gpt-4o-mini   (cheap, fast)
#   openai/gpt-4o        (more capable)
#   anthropic/claude-3-haiku   (fast, cheap via OpenRouter)
#   meta-llama/llama-3.1-8b-instruct:free  (free tier)
llm:
  provider: openrouter
  base_url: https://openrouter.ai/api/v1
  model: openai/gpt-4o-mini
  api_key_env: OPENROUTER_API_KEY
  temperature: 0.2

scenarios:
  - id: healthcare_patient_summary
    enabled: true

channels:
  - user_input
  - final_output
  - inter_agent_message
  - shared_memory
  - tool_call
  - tool_response
  - log
  - generated_file

detectors:
  pii: true
  secrets: true
  healthcare: true
  finance: false
  hr: false

scoring:
  fail_below: 40
  conditional_below: 70
  block_on_critical: true
  # AgentRisk severity weights for levels L1..L4 (only ratios matter).
  weights: [1, 2, 3, 4]
  # Override the default data_type -> severity level mapping if needed:
  # level_overrides:
  #   person_name: 3

# Optional audited vault scope (the denominator rho_S for the Risk Index).
# When unset, AgentRisk uses the observed reachable set (all secrets detected).
# vault:
#   levels: { 1: 5, 2: 3, 3: 2, 4: 1 }   # per-level secret counts
#   scope_def: "clinic scheduling workflow, access-control manifest v3"

reports:
  output_dir: reports
  formats:
    - json
    - html
    - markdown

privacy:
  redact_values: true
  # Cross-session leak detection. Names whose data each run is about, so a
  # secret written to memory while serving one person and repeated while
  # serving another is caught — the failure per-run analysis cannot see.
  # subject_ledger: .agentleak/subjects.jsonl
  store_raw_traces: false

# Optional privacy assertions. Any violation blocks the run in CLI, CI, SDK,
# the web platform, and autonomous-agent self-tests.
# privacy_policy:
#   # Contextual integrity: which flows of which data are appropriate. Every
#   # assertion below judges data *presence*; these judge the flow. A SIN
#   # reaching a KYC vendor for an identity check and the same SIN reaching an
#   # analytics sink are identical to every other rule here, and opposite under
#   # privacy law.
#   #
#   # An allow rule is scoped default-deny: naming `sin` means SIN may reach the
#   # recipients you listed and nowhere else, while data types you have said
#   # nothing about stay unjudged. A deny rule wins over any allow rule.
#   flows:
#     - data_type: sin
#       to: kyc-vendor
#       for: identity_check
#     - data_type: [health_condition, medication]
#       to: [clinician, ehr]
#     - data_type: "*"
#       to: analytics
#       deny: true
#       description: "Nothing personal reaches the analytics sink."
#   max_risk_index: 0.20
#   max_findings: 0
#   forbid_levels: [4]
#   forbid_channels: [log, shared_memory]
#   forbid_data_types: [llm_api_key, credit_card]
#   require_explicit_vault: true

# custom_detectors:
#   - name: internal_project_code
#     pattern: "PROJECT-[A-Z]{3}-[0-9]{4}"
#     severity: high
#     data_type: internal_project
"""
